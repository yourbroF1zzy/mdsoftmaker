# mdsoftmaker
A easy way to create simple programs<br>
please note that windows flags this as malicious even though its not<br>
# releases<br>
* https://github.com/yourbroF1zzy/mdsoftmaker/releases/64bit - 64 bit
* https://github.com/yourbroF1zzy/mdsoftmaker/releases/32bit - 32 bit
